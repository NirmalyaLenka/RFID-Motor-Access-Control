# Wiring Guide

## Overview

This project uses three communication protocols:
- SPI — for MFRC522 RFID module
- I2C — for SSD1306 OLED display
- GPIO — for LEDs and buzzer

---

## MFRC522 RFID Module (SPI)

The MFRC522 operates at 3.3V. Do not connect VCC to 5V — it can damage the module.

```
MFRC522         Arduino Uno
-------         -----------
VCC    ──────►  3.3V
GND    ──────►  GND
RST    ──────►  D9
SDA    ──────►  D10  (SPI Slave Select)
MOSI   ──────►  D11  (SPI MOSI)
MISO   ──────►  D12  (SPI MISO)
SCK    ──────►  D13  (SPI Clock)
IRQ    ──────►  Not connected
```

---

## SSD1306 OLED Display (I2C)

The I2C address is 0x3C (most common). If your display does not initialise, try 0x3D and update `OLED_ADDRESS` in the sketch.

```
SSD1306         Arduino Uno
-------         -----------
VCC    ──────►  5V (or 3.3V)
GND    ──────►  GND
SCL    ──────►  A5  (I2C Clock)
SDA    ──────►  A4  (I2C Data)
```

---

## LEDs

Both LEDs need a current-limiting resistor (220Ω recommended).

```
Green LED  Anode (+) ──► D7 ──► 220Ω ──► LED ──► GND
Red LED    Anode (+) ──► D6 ──► 220Ω ──► LED ──► GND
```

---

## Buzzer

Use an active buzzer (it has an internal oscillator — just needs HIGH/LOW).

```
Buzzer (+) ──────► D8
Buzzer (-) ──────► GND
```

If you only have a passive buzzer, you will need to use `tone()` instead of `digitalWrite()` in the sketch.

---

## Pin Summary

| Pin | Function |
|---|---|
| D6 | Red LED |
| D7 | Green LED |
| D8 | Buzzer |
| D9 | MFRC522 RST |
| D10 | MFRC522 SS (SDA) |
| D11 | MFRC522 MOSI |
| D12 | MFRC522 MISO |
| D13 | MFRC522 SCK |
| A4 | OLED SDA |
| A5 | OLED SCL |

---

## Power Note

The MFRC522 and SSD1306 can both be powered from the Arduino 3.3V pin at low current draw. If you experience instability, power them from an external 3.3V regulated supply and share a common GND with the Arduino.
