# Schematic Description

This document describes the electrical connections for the RFID Access Control System.

---

## Block Diagram

```
                        ┌─────────────────┐
                        │   Arduino Uno   │
                        │                 │
  ┌──────────┐   SPI    │  D10 D11 D12   │
  │ MFRC522  │◄────────►│  D13 D9        │
  │  RFID    │          │                 │
  └──────────┘          │  A4  A5        │◄────► SSD1306 OLED (I2C)
                        │                 │
                        │  D7            │──────► Green LED ──► GND
                        │  D6            │──────► Red LED   ──► GND
                        │  D8            │──────► Buzzer    ──► GND
                        └─────────────────┘
```

---

## Signal Flow

1. Arduino initialises SPI bus and I2C bus on boot
2. MFRC522 continuously polls for cards via SPI
3. When a card is detected, UID bytes are read
4. UID is compared against the authorised and denied lists in firmware
5. Result is displayed on the OLED via I2C
6. LED and buzzer provide supplementary feedback

---

## Voltage Levels

| Component | VCC | Logic |
|---|---|---|
| Arduino Uno | 5V USB / barrel jack | 5V |
| MFRC522 | 3.3V | 3.3V |
| SSD1306 OLED | 3.3V–5V | 3.3V (I2C pull-ups) |
| LEDs | — | 5V via 220Ω |
| Buzzer | — | 5V |

---

## Notes

- The MFRC522 SPI lines are 3.3V. The Arduino Uno's 5V SPI output may exceed safe levels; in practice most MFRC522 modules are 5V-tolerant on MOSI/SCK/SS due to internal clamping, but for long-term reliability a level shifter on MOSI, SCK, and SS is recommended.
- The OLED I2C lines have on-board pull-ups; no external resistors are needed.
- Keep RFID module away from metal surfaces to avoid detuning the antenna.
