# RFID Access Control System

An Arduino Uno based RFID door access controller with SSD1306 OLED feedback, LED indicators, and buzzer alerts. Authorised cards display a welcome message on the OLED; denied cards get a rejection message. Unknown cards are flagged separately.

---

## Features

- MFRC522 RFID reader for card scanning
- SSD1306 128x64 OLED display for real-time status feedback
- Green LED + double beep + **DC Motor ON (clockwise)** for access granted
- Red LED + long beep for access denied
- Unknown card handling with admin contact prompt
- Serial monitor output for UID logging and new card enrollment
- Easily expandable UID whitelists and blacklists

---

## Hardware Required

| Component | Quantity |
|---|---|
| Arduino Uno | 1 |
| MFRC522 RFID Module | 1 |
| SSD1306 OLED Display (128x64, I2C) | 1 |
| Active Buzzer | 1 |
| Green LED | 1 |
| Red LED | 1 |
| DC Motor + Driver (L298N recommended) | 1 |
| 220Ω Resistors | 2 |
| Jumper Wires | as needed |
| Breadboard | 1 |

---

## Wiring

### MFRC522 to Arduino Uno (SPI)

| MFRC522 Pin | Arduino Uno Pin |
|---|---|
| SDA (SS) | D10 |
| SCK | D13 |
| MOSI | D11 |
| MISO | D12 |
| IRQ | Not connected |
| GND | GND |
| RST | D9 |
| 3.3V | 3.3V |

### SSD1306 OLED to Arduino Uno (I2C)

| OLED Pin | Arduino Uno Pin |
|---|---|
| VCC | 3.3V or 5V |
| GND | GND |
| SCL | A5 |
| SDA | A4 |

### Other Components

| Component | Arduino Pin |
|---|---|
| Buzzer (+) | D8 |
| Green LED (+) | D7 |
| Red LED (+) | D6 |
| Motor Control | D5 (via Motor Driver) |
| LED/Buzzer (−) | GND (via 220Ω) |

**⚠️ Important**: Do **NOT** connect motor directly to D5. Use a motor driver module (L298N, TB6612, etc.) with separate power supply. Share GND with Arduino.

---

## Libraries

Install all of these via Arduino IDE → Tools → Manage Libraries:

- **MFRC522** by GithubCommunity
- **Adafruit SSD1306** by Adafruit
- **Adafruit GFX Library** by Adafruit

---

## Uploading

1. Clone this repository
2. Open `src/rfid_access_control.ino` in Arduino IDE
3. Install the required libraries listed above
4. Select board: **Arduino Uno**
5. Select the correct COM port
6. Click Upload

---

## Adding or Changing Cards

Open the Serial Monitor at **9600 baud** and scan any card. The UID will be printed in hex format like:

```
Card UID: C0 8B 16 25
```

To authorise a card, add its UID to the `AUTHORIZED_UIDS` array in the sketch:

```cpp
const byte AUTHORIZED_UIDS[][4] = {
  { 0x13, 0xC0, 0x92, 0xF5 },  // existing card
  { 0xAB, 0xCD, 0xEF, 0x12 }   // new card
};
```

To block a card, add it to `DENIED_UIDS` instead.

---

## OLED Behavior

| Scenario | OLED Message |
|---|---|
| Idle / waiting | "Scan your card..." |
| Authorised card | ACCESS GRANTED — ANDAR AJAO |
| Denied card | ACCESS DENIED — HAT JAO LODE KE SAMNE SE |
| Unknown card | UNKNOWN CARD — Contact admin |

---

## Project Structure

```
rfid-access-control/
├── src/
│   └── rfid_access_control.ino   # Main Arduino sketch
├── docs/
│   └── wiring_guide.md           # Detailed wiring reference
├── schematics/
│   └── schematic_description.md  # Pin map and connection details
├── .gitignore
├── LICENSE
└── README.md
```

---

## Author

**NirmalyaLenka**
GitHub: [github.com/NirmalyaLenka](https://github.com/NirmalyaLenka)

---

## License

MIT License. See [LICENSE](LICENSE) for details.
